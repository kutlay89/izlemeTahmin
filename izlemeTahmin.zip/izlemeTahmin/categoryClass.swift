//
//  categoryClass.swift
//  izlemeTahmin
//
//  Created by Yusiff on 25.06.2024.
//

import Foundation

class category{


}
