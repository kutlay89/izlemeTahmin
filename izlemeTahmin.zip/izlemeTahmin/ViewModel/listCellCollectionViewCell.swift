//
//  listCellCollectionViewCell.swift
//  izlemeTahmin
//
//  Created by Yusiff on 23.06.2024.
//

import UIKit

class listCellCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var listImage: UIImageView!
}
